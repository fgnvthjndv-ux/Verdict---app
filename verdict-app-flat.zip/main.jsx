import React from "react";
import ReactDOM from "react-dom/client";
import Verdict from "./Verdict.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <Verdict />
  </React.StrictMode>
);
