import React, { useState, useMemo, useRef, useEffect, useCallback } from "react";

// ---- Mock data: stands in for a real ratings-aggregation API ----
const BOOKS = [
  {
    id: 1,
    title: "The Midnight Library",
    author: "Matt Haig",
    year: 2020,
    tags: ["fiction", "philosophy"],
    avgRating: 4.2,
    pacing: 62,
    endingQuality: 48,
    hypeGap: 71,
    finisherRating: 3.4,
    verdict: "OVERHYPED",
    note: "Strong premise, but readers who finish it report the back half repeats the same beat until the ending arrives abruptly.",
  },
  {
    id: 2,
    title: "Project Hail Mary",
    author: "Andy Weir",
    year: 2021,
    tags: ["sci-fi"],
    avgRating: 4.7,
    pacing: 91,
    endingQuality: 88,
    hypeGap: 8,
    finisherRating: 4.6,
    verdict: "VERIFIED",
    note: "Rare case where the hype and the finisher reviews agree almost exactly. Ending sticks the landing.",
  },
  {
    id: 3,
    title: "Fourth Wing",
    author: "Rebecca Yarros",
    year: 2023,
    tags: ["fantasy", "romance"],
    avgRating: 4.6,
    pacing: 85,
    endingQuality: 55,
    hypeGap: 64,
    finisherRating: 3.7,
    verdict: "MIXED",
    note: "Fast, addictive first two-thirds. Finisher reviews cool noticeably in the last act — cliffhanger frustrates as many as it hooks.",
  },
  {
    id: 4,
    title: "Tomorrow, and Tomorrow, and Tomorrow",
    author: "Gabrielle Zevin",
    year: 2022,
    tags: ["fiction"],
    avgRating: 4.4,
    pacing: 58,
    endingQuality: 82,
    hypeGap: 12,
    finisherRating: 4.5,
    verdict: "VERIFIED",
    note: "Slow middle by design. Readers who push through consistently rate the ending among the best of the year.",
  },
  {
    id: 5,
    title: "It Ends With Us",
    author: "Colleen Hoover",
    year: 2016,
    tags: ["romance"],
    avgRating: 4.5,
    pacing: 79,
    endingQuality: 41,
    hypeGap: 68,
    finisherRating: 3.2,
    verdict: "OVERHYPED",
    note: "BookTok momentum dwarfs finisher sentiment. Common complaint: tonal whiplash in final chapters.",
  },
  {
    id: 6,
    title: "The Name of the Wind",
    author: "Patrick Rothfuss",
    year: 2007,
    tags: ["fantasy"],
    avgRating: 4.5,
    pacing: 74,
    endingQuality: 22,
    hypeGap: 55,
    finisherRating: 3.9,
    verdict: "CAUTION",
    note: "Beloved prose, but there is no ending — book one of an unfinished trilogy. Score reflects that risk, not quality.",
  },
  {
    id: 7,
    title: "Piranesi",
    author: "Susanna Clarke",
    year: 2020,
    tags: ["fiction", "fantasy"],
    avgRating: 4.4,
    pacing: 80,
    endingQuality: 90,
    hypeGap: 6,
    finisherRating: 4.5,
    verdict: "VERIFIED",
    note: "Short, tightly wound, and the ending reframes everything before it. Near-universal praise from finishers.",
  },
  {
    id: 8,
    title: "A Court of Thorns and Roses",
    author: "Sarah J. Maas",
    year: 2015,
    tags: ["fantasy", "romance"],
    avgRating: 4.3,
    pacing: 70,
    endingQuality: 60,
    hypeGap: 47,
    finisherRating: 3.8,
    verdict: "MIXED",
    note: "Slow opening third turns off a chunk of readers before it earns its momentum. Worth pushing past chapter ten.",
  },
];

const VERDICT_STYLES = {
  VERIFIED: { color: "#2F6844", label: "VERIFIED", angle: -6 },
  MIXED: { color: "#8A6A1E", label: "MIXED SIGNAL", angle: -3 },
  OVERHYPED: { color: "#A8322D", label: "OVERHYPED", angle: -8 },
  CAUTION: { color: "#A8322D", label: "READ W/ CAUTION", angle: -5 },
};

function Stamp({ verdict, size = "normal" }) {
  const s = VERDICT_STYLES[verdict];
  const big = size === "large";
  return (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        border: `${big ? 3 : 2}px solid ${s.color}`,
        borderRadius: "6px",
        color: s.color,
        fontFamily: "'Courier New', monospace",
        fontWeight: 700,
        letterSpacing: big ? "0.12em" : "0.08em",
        padding: big ? "10px 20px" : "4px 10px",
        fontSize: big ? "18px" : "11px",
        transform: `rotate(${s.angle}deg)`,
        opacity: 0.9,
        whiteSpace: "nowrap",
        background: "rgba(255,255,255,0.4)",
      }}
    >
      {s.label}
    </div>
  );
}

function ScoreBar({ label, value, max = 100, invert = false }) {
  const pct = Math.max(0, Math.min(100, value));
  const good = invert ? pct < 40 : pct > 60;
  const mid = pct >= 40 && pct <= 60;
  const color = good ? "#2F6844" : mid ? "#8A6A1E" : "#A8322D";
  return (
    <div style={{ marginBottom: "14px" }}>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          fontFamily: "'Courier New', monospace",
          fontSize: "11px",
          letterSpacing: "0.05em",
          color: "#5A5648",
          marginBottom: "4px",
          textTransform: "uppercase",
        }}
      >
        <span>{label}</span>
        <span>{value}/100</span>
      </div>
      <div
        style={{
          height: "6px",
          background: "#E4DCC8",
          borderRadius: "3px",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            width: `${pct}%`,
            height: "100%",
            background: color,
            borderRadius: "3px",
            transition: "width 0.6s ease",
          }}
        />
      </div>
    </div>
  );
}

function BookDetail({ book, onBack, onSave, isSaved }) {
  return (
    <div style={{ animation: "fadeIn 0.3s ease" }}>
      <button
        onClick={onBack}
        style={{
          background: "none",
          border: "none",
          color: "#5A5648",
          fontFamily: "'Courier New', monospace",
          fontSize: "12px",
          letterSpacing: "0.05em",
          cursor: "pointer",
          padding: "0 0 20px 0",
          textTransform: "uppercase",
        }}
      >
        &larr; Back to search
      </button>

      <div
        style={{
          border: "1px solid #D8CFB8",
          borderRadius: "2px",
          padding: "28px 24px",
          background: "#FBF8F0",
          position: "relative",
        }}
      >
        <div
          style={{
            position: "absolute",
            top: "20px",
            right: "20px",
          }}
        >
          <Stamp verdict={book.verdict} size="large" />
        </div>

        <div style={{ maxWidth: "62%" }}>
          <div
            style={{
              fontFamily: "'Courier New', monospace",
              fontSize: "11px",
              color: "#9A8F6F",
              letterSpacing: "0.1em",
              marginBottom: "8px",
            }}
          >
            CASE FILE No. {String(book.id).padStart(3, "0")}
          </div>
          <h2
            style={{
              fontFamily: "'Playfair Display', Georgia, serif",
              fontSize: "26px",
              fontWeight: 700,
              color: "#221F1A",
              margin: "0 0 4px 0",
              lineHeight: 1.2,
            }}
          >
            {book.title}
          </h2>
          <div
            style={{
              fontFamily: "Georgia, serif",
              fontStyle: "italic",
              color: "#5A5648",
              fontSize: "14px",
              marginBottom: "20px",
            }}
          >
            {book.author} &middot; {book.year}
          </div>
        </div>

        <div
          style={{
            borderTop: "1px dashed #D8CFB8",
            paddingTop: "20px",
            marginTop: "8px",
          }}
        >
          <ScoreBar label="Pacing" value={book.pacing} />
          <ScoreBar label="Ending quality" value={book.endingQuality} />
          <ScoreBar
            label="Hype vs. finisher gap"
            value={book.hypeGap}
            invert
          />
        </div>

        <div
          style={{
            display: "flex",
            gap: "24px",
            marginTop: "16px",
            marginBottom: "20px",
            fontFamily: "'Courier New', monospace",
            fontSize: "12px",
            color: "#5A5648",
          }}
        >
          <div>
            <div style={{ color: "#9A8F6F", fontSize: "10px" }}>
              PUBLIC AVG
            </div>
            <div style={{ fontSize: "16px", color: "#221F1A" }}>
              {book.avgRating.toFixed(1)} ★
            </div>
          </div>
          <div>
            <div style={{ color: "#9A8F6F", fontSize: "10px" }}>
              FINISHER AVG
            </div>
            <div style={{ fontSize: "16px", color: "#221F1A" }}>
              {book.finisherRating.toFixed(1)} ★
            </div>
          </div>
        </div>

        <p
          style={{
            fontFamily: "Georgia, serif",
            fontSize: "14px",
            lineHeight: 1.6,
            color: "#3A362C",
            borderLeft: "3px solid #D8CFB8",
            paddingLeft: "14px",
            margin: "0 0 20px 0",
          }}
        >
          {book.note}
        </p>

        <button
          onClick={() => onSave(book.id)}
          style={{
            background: isSaved ? "#E4DCC8" : "#221F1A",
            color: isSaved ? "#5A5648" : "#FBF8F0",
            border: "none",
            borderRadius: "2px",
            padding: "10px 18px",
            fontFamily: "'Courier New', monospace",
            fontSize: "12px",
            letterSpacing: "0.08em",
            cursor: "pointer",
            textTransform: "uppercase",
          }}
        >
          {isSaved ? "✓ On your shelf" : "+ Add to vetted shelf"}
        </button>
      </div>
    </div>
  );
}

function BookRow({ book, onClick }) {
  const s = VERDICT_STYLES[book.verdict];
  return (
    <div
      onClick={onClick}
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "16px 4px",
        borderBottom: "1px solid #E4DCC8",
        cursor: "pointer",
      }}
    >
      <div style={{ flex: 1, minWidth: 0 }}>
        <div
          style={{
            fontFamily: "'Playfair Display', Georgia, serif",
            fontSize: "17px",
            color: "#221F1A",
            fontWeight: 700,
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
          }}
        >
          {book.title}
        </div>
        <div
          style={{
            fontFamily: "Georgia, serif",
            fontStyle: "italic",
            fontSize: "12.5px",
            color: "#5A5648",
          }}
        >
          {book.author}
        </div>
      </div>
      <div
        style={{
          marginLeft: "12px",
          flexShrink: 0,
          textAlign: "right",
        }}
      >
        <div
          style={{
            fontFamily: "'Courier New', monospace",
            fontSize: "10px",
            fontWeight: 700,
            color: s.color,
            letterSpacing: "0.05em",
          }}
        >
          {s.label}
        </div>
        <div
          style={{
            fontFamily: "'Courier New', monospace",
            fontSize: "10px",
            color: "#9A8F6F",
            marginTop: "2px",
          }}
        >
          {book.finisherRating.toFixed(1)}★ finishers
        </div>
      </div>
    </div>
  );
}

function ScanModal({ onClose, onResult }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const [status, setStatus] = useState("loading"); // loading | live | error | processing
  const [errorMsg, setErrorMsg] = useState("");

  useEffect(() => {
    let cancelled = false;
    async function start() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "environment" },
          audio: false,
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }
        setStatus("live");
      } catch (err) {
        setStatus("error");
        setErrorMsg(
          err && err.name === "NotAllowedError"
            ? "Camera access was denied. Allow camera permission and try again."
            : "Couldn't reach a camera on this device."
        );
      }
    }
    start();
    return () => {
      cancelled = true;
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }
    };
  }, []);

  const capture = useCallback(() => {
    if (!videoRef.current || status !== "live") return;
    setStatus("processing");

    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Simulated recognition delay — swap for a real cover-recognition /
    // OCR+ISBN-lookup API call in production. We pick a plausible match
    // from the registry so the flow is demonstrable end-to-end.
    setTimeout(() => {
      const match = BOOKS[Math.floor(Math.random() * BOOKS.length)];
      onResult(match);
    }, 1400);
  }, [status, onResult]);

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "#0F0D09",
        zIndex: 50,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <canvas ref={canvasRef} style={{ display: "none" }} />

      <div
        style={{
          width: "100%",
          maxWidth: "480px",
          padding: "18px 20px",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <div
          style={{
            fontFamily: "'Courier New', monospace",
            fontSize: "11px",
            letterSpacing: "0.12em",
            color: "#C9BE9E",
          }}
        >
          COVER SCAN
        </div>
        <button
          onClick={onClose}
          style={{
            background: "none",
            border: "1px solid #5A5648",
            color: "#EFE8D8",
            borderRadius: "20px",
            padding: "6px 14px",
            fontFamily: "'Courier New', monospace",
            fontSize: "11px",
            cursor: "pointer",
          }}
        >
          Close
        </button>
      </div>

      <div
        style={{
          position: "relative",
          width: "100%",
          maxWidth: "480px",
          flex: 1,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          overflow: "hidden",
        }}
      >
        {status === "error" ? (
          <div
            style={{
              padding: "0 30px",
              textAlign: "center",
              fontFamily: "Georgia, serif",
              color: "#EFE8D8",
              fontSize: "14px",
              lineHeight: 1.6,
            }}
          >
            {errorMsg}
          </div>
        ) : (
          <>
            <video
              ref={videoRef}
              playsInline
              muted
              style={{
                width: "100%",
                height: "100%",
                objectFit: "cover",
                opacity: status === "processing" ? 0.35 : 1,
                transition: "opacity 0.3s ease",
              }}
            />
            {/* Framing guide */}
            <div
              style={{
                position: "absolute",
                width: "62%",
                height: "68%",
                border: "2px solid rgba(239,232,216,0.85)",
                borderRadius: "4px",
                boxShadow: "0 0 0 999px rgba(15,13,9,0.45)",
                pointerEvents: "none",
              }}
            />
            {status === "loading" && (
              <div
                style={{
                  position: "absolute",
                  fontFamily: "'Courier New', monospace",
                  fontSize: "12px",
                  color: "#EFE8D8",
                  letterSpacing: "0.08em",
                }}
              >
                Waking up the camera…
              </div>
            )}
            {status === "processing" && (
              <div
                style={{
                  position: "absolute",
                  fontFamily: "'Courier New', monospace",
                  fontSize: "12px",
                  color: "#EFE8D8",
                  letterSpacing: "0.08em",
                  textAlign: "center",
                }}
              >
                Matching cover against the registry…
              </div>
            )}
          </>
        )}
      </div>

      <div
        style={{
          padding: "24px 20px 34px 20px",
          width: "100%",
          maxWidth: "480px",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: "10px",
        }}
      >
        <button
          onClick={capture}
          disabled={status !== "live"}
          style={{
            width: "68px",
            height: "68px",
            borderRadius: "50%",
            border: "3px solid #EFE8D8",
            background: status === "live" ? "#A8322D" : "#5A5648",
            cursor: status === "live" ? "pointer" : "default",
            transition: "background 0.2s ease",
          }}
        />
        <div
          style={{
            fontFamily: "'Courier New', monospace",
            fontSize: "10px",
            color: "#9A8F6F",
            letterSpacing: "0.05em",
            textAlign: "center",
          }}
        >
          Frame the front cover, then tap to capture
        </div>
      </div>
    </div>
  );
}

export default function Verdict() {
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(null);
  const [shelf, setShelf] = useState([]);
  const [filter, setFilter] = useState("ALL");
  const [scanning, setScanning] = useState(false);
  const [justScanned, setJustScanned] = useState(null);

  const results = useMemo(() => {
    let list = BOOKS;
    if (filter !== "ALL") {
      list = list.filter((b) => b.verdict === filter);
    }
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(
        (b) =>
          b.title.toLowerCase().includes(q) ||
          b.author.toLowerCase().includes(q) ||
          b.tags.some((t) => t.includes(q))
      );
    }
    return list;
  }, [query, filter]);

  const toggleSave = (id) => {
    setShelf((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const filters = ["ALL", "VERIFIED", "MIXED", "OVERHYPED", "CAUTION"];

  const handleScanResult = (book) => {
    setScanning(false);
    setJustScanned(book.id);
    setSelected(book);
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#F1EADB",
        backgroundImage:
          "radial-gradient(circle at 20% 10%, rgba(255,255,255,0.4), transparent 40%)",
        display: "flex",
        justifyContent: "center",
        padding: "0",
      }}
    >
      <style>{`
        @keyframes fadeIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }
        * { box-sizing: border-box; }
        input:focus { outline: 2px solid #221F1A; outline-offset: 2px; }
      `}</style>
      <div
        style={{
          width: "100%",
          maxWidth: "480px",
          padding: "28px 20px 60px 20px",
        }}
      >
        <div style={{ marginBottom: "6px" }}>
          <div
            style={{
              fontFamily: "'Courier New', monospace",
              fontSize: "11px",
              letterSpacing: "0.15em",
              color: "#9A8F6F",
            }}
          >
            VOL. I &mdash; READER'S REGISTRY
          </div>
          <h1
            style={{
              fontFamily: "'Playfair Display', Georgia, serif",
              fontSize: "38px",
              fontWeight: 700,
              color: "#221F1A",
              margin: "2px 0 4px 0",
              letterSpacing: "-0.01em",
            }}
          >
            Verdict
          </h1>
          <p
            style={{
              fontFamily: "Georgia, serif",
              fontStyle: "italic",
              fontSize: "13.5px",
              color: "#5A5648",
              margin: "0 0 22px 0",
            }}
          >
            The hype gets filtered out before it reaches you.
          </p>
        </div>

        {!selected && (
          <>
            <div
              style={{
                display: "flex",
                gap: "8px",
                marginBottom: "14px",
              }}
            >
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search a title, author, or genre..."
                style={{
                  flex: 1,
                  minWidth: 0,
                  padding: "13px 14px",
                  fontFamily: "Georgia, serif",
                  fontSize: "14px",
                  border: "1px solid #C9BE9E",
                  borderRadius: "2px",
                  background: "#FBF8F0",
                  color: "#221F1A",
                }}
              />
              <button
                onClick={() => setScanning(true)}
                aria-label="Scan a book cover"
                style={{
                  flexShrink: 0,
                  width: "46px",
                  border: "1px solid #221F1A",
                  borderRadius: "2px",
                  background: "#221F1A",
                  color: "#EFE8D8",
                  cursor: "pointer",
                  fontSize: "18px",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                📷
              </button>
            </div>

            <div
              style={{
                display: "flex",
                gap: "6px",
                flexWrap: "wrap",
                marginBottom: "10px",
              }}
            >
              {filters.map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  style={{
                    fontFamily: "'Courier New', monospace",
                    fontSize: "10.5px",
                    letterSpacing: "0.05em",
                    padding: "6px 10px",
                    borderRadius: "20px",
                    border: `1px solid ${
                      filter === f ? "#221F1A" : "#C9BE9E"
                    }`,
                    background: filter === f ? "#221F1A" : "transparent",
                    color: filter === f ? "#FBF8F0" : "#5A5648",
                    cursor: "pointer",
                  }}
                >
                  {f === "ALL" ? "ALL" : VERDICT_STYLES[f].label}
                </button>
              ))}
            </div>

            {shelf.length > 0 && (
              <div
                style={{
                  fontFamily: "'Courier New', monospace",
                  fontSize: "11px",
                  color: "#5A5648",
                  marginBottom: "14px",
                }}
              >
                {shelf.length} book{shelf.length > 1 ? "s" : ""} on your
                vetted shelf
              </div>
            )}

            <div
              style={{
                borderTop: "1px solid #221F1A",
                marginTop: "6px",
              }}
            >
              {results.length === 0 ? (
                <div
                  style={{
                    padding: "30px 4px",
                    fontFamily: "Georgia, serif",
                    fontStyle: "italic",
                    color: "#9A8F6F",
                    fontSize: "13px",
                  }}
                >
                  No entries match that search in the registry yet.
                </div>
              ) : (
                results.map((b) => (
                  <BookRow
                    key={b.id}
                    book={b}
                    onClick={() => setSelected(b)}
                  />
                ))
              )}
            </div>

            <div
              style={{
                marginTop: "30px",
                fontFamily: "'Courier New', monospace",
                fontSize: "10.5px",
                color: "#9A8F6F",
                lineHeight: 1.6,
                borderTop: "1px dashed #D8CFB8",
                paddingTop: "16px",
              }}
            >
              Verdicts compare public star averages against reviews left by
              readers confirmed to have finished the book — this sample is
              illustrative; wire up a real ratings API to make it live.
            </div>
          </>
        )}

        {selected && (
          <>
            {justScanned === selected.id && (
              <div
                style={{
                  fontFamily: "'Courier New', monospace",
                  fontSize: "11px",
                  color: "#2F6844",
                  letterSpacing: "0.05em",
                  marginBottom: "10px",
                }}
              >
                ✓ MATCHED FROM COVER SCAN
              </div>
            )}
            <BookDetail
              book={selected}
              onBack={() => {
                setSelected(null);
                setJustScanned(null);
              }}
              onSave={toggleSave}
              isSaved={shelf.includes(selected.id)}
            />
          </>
        )}
      </div>

      {scanning && (
        <ScanModal
          onClose={() => setScanning(false)}
          onResult={handleScanResult}
        />
      )}
    </div>
  );
}
