# Verdict — Deploy from your iPhone

Every file in this zip sits at the top level — no folders to worry about.
This makes it safe to upload through GitHub's mobile website, which can
mangle nested folders.

## Step 1 — Get a GitHub account
Open Safari, go to https://github.com/signup, create a free account.

## Step 2 — Create a new repository
1. Tap the **+** icon (top right) → **New repository**
2. Name it `verdict-app`
3. Set it to **Public**
4. Tap **Create repository**

## Step 3 — Unzip on your phone
Open this zip in the **Files** app — tap it once and iOS will
automatically extract a `verdict-app` folder next to it. Open that
folder — you should see about 8 individual files, no subfolders.

## Step 4 — Upload the files to GitHub
1. In your new repo on GitHub, tap **"uploading an existing file"**
   (or Add file → Upload files)
2. Tap **"choose your files"**, then in the file picker navigate to
   Files app → the unzipped `verdict-app` folder
3. Select **all files** (tap Select, then tap each one, or "Select All")
4. Tap **Upload**, scroll down, tap **Commit changes**

You should now see all the files listed flat in your GitHub repo — no
folders.

## Step 5 — Deploy with Vercel
1. Go to https://vercel.com/signup
2. Tap **Continue with GitHub** and authorize it
3. Tap **Add New...** → **Project**
4. Find `verdict-app` in the list, tap **Import**
5. Leave every setting on its default, tap **Deploy**
6. Wait ~60 seconds — Vercel builds it on their servers, not your phone

You'll land on a page with a live URL like
`https://verdict-app-yourname.vercel.app` — tap it, it opens your app.

## Step 6 — Add it to your Home Screen
1. In that Vercel URL, tap the **Share** icon in Safari
2. Tap **Add to Home Screen**
3. Give it a name (e.g. "Verdict"), tap **Add**

You now have a real app icon on your home screen. Tapping it opens
full-screen, no browser bar. Camera scan works because Vercel serves
everything over HTTPS, which is required for camera access.

## Updating the app later
Any time you want to change something: edit the file directly on
GitHub (tap the file, tap the pencil icon, edit, commit). Vercel
automatically redeploys within about a minute of any commit — no
extra steps needed.

## What's real vs. placeholder (same as before)
- The 8 books and their scores are hardcoded sample data.
- The camera really opens and captures a photo, but the "match" is
  randomly picked from the 8 books — no real recognition yet. Wiring
  that up for real is the natural next step once you're ready.
